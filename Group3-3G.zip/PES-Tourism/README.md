# PES Tourism
 * A Software Engineering Web Based Application
 * Clone the repository and run ```npm install``` to install all necessary pacakages
 * run ```node app.js``` to run the application in the node.js command prompt
 * in Chrome or Edge browser open http://localhost:3000 to open the web-application in browser
 *
 